namespace AulaPOO.Interfaces
{
    using AulaPOO.Models;

    public interface IEmprestavel
    {
        void Emprestar(Usuario usuario);
        void Devolver(Usuario usuario);
        bool VerificarDisponibilidade();
    }
}