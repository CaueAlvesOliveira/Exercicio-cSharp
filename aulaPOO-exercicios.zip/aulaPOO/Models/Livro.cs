using System;

namespace AulaPOO.Models
{
    // Classe representa um Livro
    public class Livro
    {

        // Atributos (propriedades)
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string ISBN { get; set; }
        public int AnoPublicacao { get; set; }
        public int Paginas { get; set; }
        public bool Disponivel { get; private set; }
        public DateTime? DataEmprestimo { get; private set; }
        public DateTime? DataDevolucaoPrevista { get; private set; }

        // Construtor
        public Livro(string titulo, string autor, string isbn, int ano, int paginas)
        {
            Titulo = titulo;
            Autor = autor;
            ISBN = isbn;
            AnoPublicacao = ano;
            Paginas = paginas;
            Disponivel = true; // Novo livro sempre disponível
        }

        // Métodos
        public void Emprestar(DateTime dataDevolucaoPrevista)
        {
            if (dataDevolucaoPrevista.Date <= DateTime.Today)
            {
                Console.WriteLine("Data de devolução deve ser futura.");
                return;
            }

            if (Disponivel)
            {
                Disponivel = false;
                DataEmprestimo = DateTime.Today;
                DataDevolucaoPrevista = dataDevolucaoPrevista.Date;
                Console.WriteLine($"Livro '{Titulo}' emprestado com sucesso!");
            }
            else
            {
                Console.WriteLine($"Livro '{Titulo}' não está disponível para empréstimo.");
            }
        }

        public void Devolver()
        {
            if (!Disponivel)
            {
                Disponivel = true;
                DataEmprestimo = null;
                DataDevolucaoPrevista = null;
                Console.WriteLine($"Livro '{Titulo}' devolvido com sucesso!");
            }
            else
            {
                Console.WriteLine($"Livro '{Titulo}' já está disponível.");
            }
        }

        public decimal CalcularMultaPorAtraso(DateTime dataDevolucaoReal, decimal valorDiarioMulta)
        {
            if (!DataDevolucaoPrevista.HasValue || dataDevolucaoReal.Date <= DataDevolucaoPrevista.Value.Date)
            {
                return 0m;
            }

            var diasAtraso = (dataDevolucaoReal.Date - DataDevolucaoPrevista.Value.Date).Days;
            return diasAtraso * valorDiarioMulta;
        }

        public void ExibirInformacoes()
        {
            Console.WriteLine($"\n--- Informações do Livro ---");
            Console.WriteLine($"Título: {Titulo}");
            Console.WriteLine($"Autor: {Autor}");
            Console.WriteLine($"ISBN: {ISBN}");
            Console.WriteLine($"Ano: {AnoPublicacao}");
            Console.WriteLine($"Páginas: {Paginas}");
            Console.WriteLine($"Status: {(Disponivel ? "Disponível" : "Emprestado")}");
            if (!Disponivel && DataDevolucaoPrevista.HasValue)
            {
                Console.WriteLine($"Devolução prevista: {DataDevolucaoPrevista.Value:dd/MM/yyyy}");
            }
        }
    }
}