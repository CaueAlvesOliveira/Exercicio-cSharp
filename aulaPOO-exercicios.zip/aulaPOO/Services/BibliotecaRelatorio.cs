using System;
using System.Linq;
using AulaPOO.Models;

namespace AulaPOO.Services
{
    public class BibliotecaRelatorio
    {
        private readonly BibliotecaService _bibliotecaService;

        public BibliotecaRelatorio(BibliotecaService bibliotecaService)
        {
            _bibliotecaService = bibliotecaService;
        }

        public int TotalLivros()
        {
            return _bibliotecaService.ObterLivros().Count;
        }

        public int TotalLivrosDisponiveis()
        {
            return _bibliotecaService.ObterLivros().Count(l => l.Disponivel);
        }

        public int TotalLivrosEmprestados()
        {
            return _bibliotecaService.ObterLivros().Count(l => !l.Disponivel);
        }

        public int TotalUsuarios()
        {
            return _bibliotecaService.ObterUsuarios().Count;
        }

        public decimal TotalMultasAcumuladas()
        {
            return _bibliotecaService.ObterUsuarios().Sum(u => u.MultaTotal);
        }

        public double MediaLivrosEmprestadosPorUsuario()
        {
            var usuarios = _bibliotecaService.ObterUsuarios();
            if (usuarios.Count == 0)
            {
                return 0;
            }

            return usuarios.Average(u => u.QuantidadeLivrosEmprestados);
        }

        public string AutorComMaisLivrosNoAcervo()
        {
            var autor = _bibliotecaService
                .ObterLivros()
                .Where(l => !string.IsNullOrWhiteSpace(l.Autor))
                .GroupBy(l => l.Autor)
                .OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .FirstOrDefault();

            return autor ?? "Sem dados";
        }

        public void ExibirResumoEstatistico()
        {
            Console.WriteLine("\n=== RELATORIO ESTATISTICO ===");
            Console.WriteLine($"Total de livros: {TotalLivros()}");
            Console.WriteLine($"Livros disponiveis: {TotalLivrosDisponiveis()}");
            Console.WriteLine($"Livros emprestados: {TotalLivrosEmprestados()}");
            Console.WriteLine($"Total de usuarios: {TotalUsuarios()}");
            Console.WriteLine($"Media de livros emprestados por usuario: {MediaLivrosEmprestadosPorUsuario():F2}");
            Console.WriteLine($"Autor com mais livros no acervo: {AutorComMaisLivrosNoAcervo()}");
            Console.WriteLine($"Total em multas acumuladas: {TotalMultasAcumuladas():C}");
        }
    }
}
