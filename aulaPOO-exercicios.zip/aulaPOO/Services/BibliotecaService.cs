using System;
using System.Collections.Generic;
using AulaPOO.Models;

namespace AulaPOO.Services
{
    public class BibliotecaService
    {
        private const decimal MultaDiariaAtraso = 2.50m;
        private List<Livro> _livros;
        private List<Usuario> _usuarios;

        public BibliotecaService()
        {
            _livros = new List<Livro>();
            _usuarios = new List<Usuario>();
        }

        public void AdicionarLivro(Livro livro)
        {
            _livros.Add(livro);
            Console.WriteLine($"Livro '{livro.Titulo}' adicionado à biblioteca");
        }

        public void AdicionarUsuario(Usuario usuario)
        {
            _usuarios.Add(usuario);
            Console.WriteLine($"Usuário '{usuario.Nome}' registrado na biblioteca");
        }

        public void RealizarEmprestimo(string isbn, string usuarioNome, DateTime dataDevolucaoPrevista)
        {
            var livro = _livros.Find(l => l.ISBN == isbn);
            var usuario = _usuarios.Find(u => u.Nome == usuarioNome);
            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado!");
                return;
            }
            if (usuario == null)
            {
                Console.WriteLine("Usuário não encontrado!");
                return;
            }

            if (dataDevolucaoPrevista.Date <= DateTime.Today)
            {
                Console.WriteLine("Data de devolução inválida. Informe uma data futura.");
                return;
            }

            livro.Emprestar(dataDevolucaoPrevista);
            if (!livro.Disponivel)
            {
                usuario.AdicionarLivro(livro);
            }
        }

        public void ListarTodosLivros()
        {
            Console.WriteLine("\n=== ACERVO DA BIBLIOTECA ===");
            foreach (var livro in _livros)
            {
                livro.ExibirInformacoes();
            }
        }

        public void ListarUsuarios()
        {
            Console.WriteLine("\n=== USUÁRIOS CADASTRADOS ===");
            foreach (var usuario in _usuarios)
            {
                Console.WriteLine($"- {usuario.Nome} ({usuario.Email}) | Multas: {usuario.MultaTotal:C}");
                if (usuario is UsuarioPremium premium)
                {
                    Console.WriteLine($" [Premium] Desconto: {premium.Desconto:P}");
                }
            }
        }

        public void RealizarDevolucao(string isbn, string usuarioNome, DateTime dataDevolucaoReal)
        {
            var livro = _livros.Find(l => l.ISBN == isbn);
            var usuario = _usuarios.Find(u => u.Nome == usuarioNome);

            if (livro == null)
            {
                Console.WriteLine("Livro não encontrado!");
                return;
            }

            if (usuario == null)
            {
                Console.WriteLine("Usuário não encontrado!");
                return;
            }

            if (livro.Disponivel)
            {
                Console.WriteLine("Este livro já está disponível na biblioteca.");
                return;
            }

            var multa = livro.CalcularMultaPorAtraso(dataDevolucaoReal, MultaDiariaAtraso);
            if (multa > 0)
            {
                usuario.RegistrarMulta(multa);
                Console.WriteLine($"Devolução com atraso. Multa aplicada: {multa:C}");
            }
            else
            {
                Console.WriteLine("Devolução dentro do prazo. Sem multa.");
            }

            livro.Devolver();
            usuario.RemoverLivro(livro);
        }

        public List<Livro> BuscarLivrosPorAutor(string autor)
        {
            if (string.IsNullOrWhiteSpace(autor))
            {
                return new List<Livro>();
            }

            return _livros.FindAll(l =>
                !string.IsNullOrWhiteSpace(l.Autor) &&
                l.Autor.Contains(autor, StringComparison.OrdinalIgnoreCase));
        }

        public IReadOnlyList<Livro> ObterLivros()
        {
            return _livros.AsReadOnly();
        }

        public IReadOnlyList<Usuario> ObterUsuarios()
        {
            return _usuarios.AsReadOnly();
        }
    }
}